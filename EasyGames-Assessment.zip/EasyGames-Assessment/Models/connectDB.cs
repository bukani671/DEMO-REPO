﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
namespace EasyGames_Assessment.Models
{
    class ConnectDB
    {
        static private string connectionString = @"Data Source=DESKTOP-GO28VG8\SQLEXPRESS;Initial Catalog=EasyGamesDatabase;Integrated Security=True;Pooling=False";
        private SqlConnection connection = new SqlConnection(connectionString);

        public SqlConnection GetConnection()
        {
            if (connection.State == ConnectionState.Closed)
                connection.Open();
              Console.Write("DATABASE CONNECTED"); 
            return connection;  
        }

        public SqlConnection CloseConnection()
        {
            if (connection.State == ConnectionState.Open)
                connection.Close();
            return connection;
        }
    }
}
