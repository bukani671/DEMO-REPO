﻿using System.Data;
using System.Data.SqlClient;

namespace EasyGames_Assessment.Models
{
    class ClTransactions
    {
        private ConnectDB Connect = new ConnectDB();
        private SqlCommand command = new SqlCommand();
        private SqlDataReader reader;

        public DataTable listClient()
        {
            DataTable dataTable = new DataTable();
            command.Connection = Connect.GetConnection();
            command.CommandText = "clientList";
            command.CommandType = CommandType.StoredProcedure;
            reader = command.ExecuteReader();
            dataTable.Load(reader);
            reader.Close();
            Connect.CloseConnection();
            return dataTable;

        }
        public DataTable listTransactionTypes()
        {
            DataTable dataTable = new DataTable();
            command.Connection = Connect.GetConnection();
            command.CommandText = "typelist";
            command.CommandType = CommandType.StoredProcedure;
            reader = command.ExecuteReader();
            dataTable.Load(reader);
            reader.Close();
            Connect.CloseConnection();
            return dataTable;
        }
        public DataTable listTransactions()
        {
            DataTable dataTable = new DataTable();
            command.Connection = Connect.GetConnection();
            command.CommandText = "listTransations";
            command.CommandType = CommandType.StoredProcedure;
            reader = command.ExecuteReader();
            dataTable.Load(reader);
            reader.Close();
            Connect.CloseConnection();
            return dataTable;
        }

        public DataTable DisplaySelected(int id)
        {
            DataTable dataTable = new DataTable();
            command.Connection = Connect.GetConnection();
            command.CommandText = "displaySelected";
            command.CommandType = CommandType.StoredProcedure;
            command.Parameters.AddWithValue("@ID", id);
            reader = command.ExecuteReader();
            dataTable.Load(reader);
            reader.Close();
            Connect.CloseConnection();
            return dataTable;
        }

        public void insertClient(string Name, string Surname, double Balance)
        {
            command.Connection = Connect.GetConnection();
            command.CommandText = "addClient";
            command.CommandType = CommandType.StoredProcedure;
            command.Parameters.AddWithValue("@NAM", Name);
            command.Parameters.AddWithValue("@SUR", Surname);
            command.Parameters.AddWithValue("@BAL ", Balance);
            command.ExecuteNonQuery();
            command.Parameters.Clear();
        }

        public void insertTransactions(double amount,int transID, int ClientID,string comment)
        {
            command.Connection = Connect.GetConnection();
            command.CommandText = "insertTransaction";
            command.CommandType = CommandType.StoredProcedure;
            command.Parameters.AddWithValue("@AMOUNT", amount);
            command.Parameters.AddWithValue("@TRANSTYPEID", transID);
            command.Parameters.AddWithValue("@CLIENTID", ClientID);
            command.Parameters.AddWithValue("@COMMENT", comment);
            command.ExecuteNonQuery();
            command.Parameters.Clear();
        }

    }
}
