﻿using EasyGames_Assessment.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EasyGames_Assessment
{
    public partial class Form2 : Form
    {
        ClTransactions objTransactions = new ClTransactions();
        public Form2()
        {
            InitializeComponent();
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            objTransactions.insertClient(textName.Text, textSurname.Text, Convert.ToDouble(textBalance.Text));
            MessageBox.Show("Record inserted successfully");
            TransactionForm transactionForm = new TransactionForm();
            transactionForm.Show();
            this.Hide();
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }
    }
}
