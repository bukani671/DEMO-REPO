﻿using EasyGames_Assessment.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EasyGames_Assessment
{
    public partial class TransactionForm : Form
    {
        public TransactionForm()
        {
            InitializeComponent();
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void comboClient_SelectedIndexChanged(object sender, EventArgs e)
        {
            ClTransactions clTransactions = new ClTransactions();
            dataGridView1.DataSource = clTransactions.DisplaySelected(Convert.ToInt32(comboClient.SelectedIndex));
        }
        private void comboClient_SelectedValueChanged(object sender, EventArgs e)
        {
           

        }


        private void listClient()
        {
            ClTransactions cLTransactions = new ClTransactions();
            comboClient.DataSource = cLTransactions.listClient();
            comboClient.DisplayMember =  "Person";
            comboClient.ValueMember = "ClientID";
        }

        private void listTypes()
        {
            ClTransactions clTransactions = new ClTransactions();
            comboTransType.DataSource = clTransactions.listTransactionTypes();
            comboTransType.DisplayMember = "TransactionTypeName";
            comboTransType.ValueMember = "TransactionTypeID";
        }

        private void TransactionForm_Load(object sender, EventArgs e)
        {
            listTypes();
            listClient();
            ListTransaction();
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            
            String comment = dataGridView1.SelectedColumns.ToString();
            ClTransactions clTransactions = new ClTransactions();
           clTransactions.insertTransactions(Convert.ToDouble(textAmount.Text),Convert.ToInt32(comboTransType.SelectedValue), Convert.ToInt32(comboClient.SelectedValue),comment);
            MessageBox.Show("Transaction Recorded");
            ListTransaction();
        }

        private void ListTransaction()
        {
            ClTransactions clTransactions = new ClTransactions();
            dataGridView1.DataSource = clTransactions.listTransactions();
        }

        private void dataGridView1_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {
            String comment = dataGridView1.SelectedColumns.ToString();
            ClTransactions clTransactions = new ClTransactions();
            clTransactions.insertTransactions(Convert.ToDouble(textAmount.Text), Convert.ToInt32(comboTransType.SelectedValue), Convert.ToInt32(comboClient.SelectedValue), comment);
            MessageBox.Show("Transaction Recorded");
            ListTransaction();
            ListTransaction();
        }

        private void comboClient_SelectionChangeCommitted(object sender, EventArgs e)
        {
            
          
        
    }

        private void comboClient_SelectedValueChanged_1(object sender, EventArgs e)
        {

        }
    }
}
